plugins {
    id("com.android.application")
}

android {
    namespace = "com.kanha.controller"
    compileSdk = 33

    defaultConfig {
        applicationId = "com.kanha.controller"
        minSdk = 24
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}

dependencies {
    // No external dependencies needed
}