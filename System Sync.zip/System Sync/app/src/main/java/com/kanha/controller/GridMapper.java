package com.kanha.controller;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.WindowManager;

public class GridMapper {
    public static float[] getCoordinates(Context context, String code) {
        if (code == null || code.length() < 2) return null;
        
        char colLetter = Character.toUpperCase(code.charAt(0));
        int rowNum;
        try {
            rowNum = Integer.parseInt(code.substring(1));
        } catch (NumberFormatException e) {
            return null;
        }

        int colIndex = colLetter - 'A'; // A=0, B=1... Z=25
        int rowIndex = rowNum - 1;      

        if (colIndex < 0 || colIndex > 25 || rowIndex < 0 || rowIndex > 25) return null;

        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics metrics = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(metrics);

        float cellWidth = metrics.widthPixels / 26f; 
        float cellHeight = metrics.heightPixels / 26f;

        float x = (colIndex * cellWidth) + (cellWidth / 2f);
        float y = (rowIndex * cellHeight) + (cellHeight / 2f);

        return new float[]{x, y};
    }
}