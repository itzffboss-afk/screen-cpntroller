package com.kanha.controller;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class GridOverlayView extends View {
    private Paint boxPaint;
    private Paint borderPaint;
    private Paint textPaint;
    private int cols = 26; 
    private int rows = 26;

    public GridOverlayView(Context context) {
        super(context);
        
        boxPaint = new Paint();
        boxPaint.setColor(Color.parseColor("#640A0A0A")); // 40% opacity background
        boxPaint.setStyle(Paint.Style.FILL);

        borderPaint = new Paint();
        borderPaint.setColor(Color.parseColor("#00E5FF")); // Cyan border
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(1f); 

        textPaint = new Paint();
        textPaint.setColor(Color.parseColor("#FFD54F")); // Yellow text
        textPaint.setTextSize(16f); 
        textPaint.setAntiAlias(true);
        textPaint.setTextAlign(Paint.Align.CENTER);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        
        float cellW = getWidth() / (float) cols;
        float cellH = getHeight() / (float) rows;

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                float left = c * cellW;
                float top = r * cellH;
                float right = left + cellW;
                float bottom = top + cellH;

                canvas.drawRect(left, top, right, bottom, boxPaint);
                canvas.drawRect(left, top, right, bottom, borderPaint);

                String label = "" + (char) ('A' + c) + (r + 1);
                
                Paint.FontMetrics fm = textPaint.getFontMetrics();
                float textHeight = fm.descent - fm.ascent;
                float textY = (top + (cellH / 2f)) + (textHeight / 2f) - fm.descent;

                canvas.drawText(label, left + (cellW / 2f), textY, textPaint);
            }
        }
    }
}